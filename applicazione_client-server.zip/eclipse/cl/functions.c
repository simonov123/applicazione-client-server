#include "functions.h"

void run_client(){ //funzione client principale
    build_socket();//crea socket client
    set_socket_server_address();//configura oggetto sockaddr_in
    if(connect_server() != -1){//controllo connessione
        receve_welcome_string();//ricezione stringa di benvenuto

        for(int x; x != -1; ){
            x = get_link_two_strings();//iterazione funzione concatenazione stringhe
        }

    }

    close_client();//uscita dal programma
    block_screen();
}

void error_message(char *message){//errorHandler
    printf("%s", message);
    puts("");
    block_screen();//blocco schermo
}



void block_screen(){//blocco schermo con getch
    #if defined WIN32
        puts("Press a key to continue");
        getch();
    #endif // defined
}


int get_link_two_strings(){ //funzione per la concatenazione di stringhe
    char string1[BUFFER_SIZE]= "";//stringhe di input
    char string2[BUFFER_SIZE]= "";
    char string3[BUFFER_SIZE]= "";//stringa di output
    input_string(string1);//campi di inserimento stringhe di input
    send_data(string1);
    input_string(string2);
    send_data(string2);

    receve_data(string3);//ricezione output

    if(string_control_bye(string3) == -1)//controllo di un eventuale input di uscita nella stringa
    {
        printf("You have pressed 'quit'. the connection was closed.");
        return -1;
    }else{
        printf("%s%s\n", "Word one and word two are linked in: ", string3);
        block_screen();
        return 0;
    }

}



void receve_welcome_string(){//funzione di ricezione della stringa di benvenuto
    char welcome_string[BUFFER_SIZE]= "";//tramite apposito buffer
    receve_data(welcome_string);
    printf("%s\n", welcome_string);
}

int string_control_bye(char *string){//controllo stringa di uscita
    char string_temp[BUFFER_SIZE]= "";
    strcpy(string_temp, string);//copia della stringa di output su buffer temporanero di controllo
    int control = strcmp(string_temp, "Bye");//controllo
    if(control == 0){
        return -1;
    }else{
        return 0;
    }
}

//Aggiunta clean_buffer_input() per evitare problemi dove pi� parole immesse vengano salvate malamente

void input_string(char *string){//funzione di input di una stringa
    printf("%s", "Insert a word: ");
    clean_buffer_input();
    scanf("%s",string);
    clean_buffer_input();
}


void clean_buffer_input(){//pulizia buffer di input
    fflush(stdin);
}





