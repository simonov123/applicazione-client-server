#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined WIN32
#include <conio.h>
#endif // defined
#include "functions.h"


int main(){
    run_client();//avvio client
    return 0;
}




