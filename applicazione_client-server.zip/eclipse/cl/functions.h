#include <stdio.h>
#include "client.h"

//main function che contiene istruzioni per la procedura del client
void run_client();//5

//ErrorHandler
void error_message(char *message);//21

//blocco schermo per mettere in mostra gli output
void block_screen();//29

//invoca l'invio di due stringhe al server e la ricezione della stringa unita,poi invoca il controllo di una eventuale stringa di uscita e nel caso la chiusura del programma
int get_link_two_strings();//36

//riceve la stringa di benvnuto
void receve_welcome_string();//61

//controlla se la stringa passata è "quit"
int string_control_bye(char *string);//67

//riempimento di un buffer stringa da tastiera
void input_string(char *string);//80

//pulizia buffer di input
void clean_buffer_input();//88

