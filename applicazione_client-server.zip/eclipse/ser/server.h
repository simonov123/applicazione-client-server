#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif // defined


#define IP_ADDRESS "127.0.0.1"//IP
#define SERVER_PORT 12345//PORT

#define QLEN 1//NUMERO CLIENT  DA GESTIRE

#define BUFFER_SIZE 200//DIMENSIONE BUFFER

//Funzione di Default se viene riscontrato WIN32.
void clean_win_sock();//21

//Funzione che crea la socket di benvenuto e oggetto WSA.
void build_socket();//27

//Funzione configurazione della socket di benvenuto.
void set_socket_address();//39

//Funzione che imposta il server in ascolto e chiama la funzione waiting_connection() per interagire col Client.
void set_socket_listen();//50

//Funzione che stabilisce una connessione col Cliente, gli manda un messaggio di benvenuto con le istruzioni e inizia la comunicazione ed elaborazione dati fin quando non viene chiuso il collegamento.
void waiting_connection();//58

//Funzione che invia una stringa .
void send_data(char *input_buffer);//78

//Funzione che imposta la ricezione di una stringa.
void receve_data(char *return_buffer);//83

//Funzione che invia la stringa "Bye" al Client e chiude la connessione.
void send_bye();//89

//Funzione che avvisa il Server che la comunicazione col Client ha problemi e ne chiude la connessione. Aggiunta per eventuali chiusure premature dell'applicazione Client.
void error_client_close_prematurely();//95

//Funzione che chiude la socket e la pulisce.
int close_socket_and_clean(int descriptor);//100

//Funzione che controlla eventuali errori nella funzione accept().
int check_accept(int accept_x);//109

//Funzione che controlla eventuali errori nella funzione listen().
int check_listen(int listen);//117

//Funzione che controlla la creazione della socket.
int check_socket(int my_socket);//125

//Funzione che controlla eventuali errori nella funzione bind().
int check_bind(int check_x);//134

//Funzione che controlla eventuali problemi con la porta.
int check_port(int argc, char *argv[]);//142

//Funzione che cotnrolla la creazione oggetto WSADATA
void wsadata_check(int iresult);//157
