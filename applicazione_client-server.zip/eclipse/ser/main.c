#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#if defined WIN32
#include <conio.h>
#endif // defined
#include "functions.h"


int main(int argc, char *argv[]){

    check_port(argc, &argv);
    run_server();

    return 0;
}


