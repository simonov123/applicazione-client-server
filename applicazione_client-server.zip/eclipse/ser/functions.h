#include "server.h"

//Funzione principale del server che fa partire l'applicazione, elabora i dati ed infine chiude l'applicazione.
void run_server();//4

//Funzione che mostra a schermo un messaggio di errore definito come input in "message".
void error_message(char *message);//13

//Funzione, valida solo su WIN32 e presa dalla libreria <conio.h>. Ferma l'algoritmo e blocca l'output su schermo fin quando non si preme un qualsiasi tasto da tastiera.
//Utile per lasciare a schermo eventuali scritte.
void block_screen();//21

//Funzione che concatena la stringa uno con la stringa due e la salva nella return_string.
void link_two_strings(char *string1, char *string2, char *return_string);//28

//Funzione che inizializza le 3 stringe a stringa vuota, resettando l'eventuale array.
void reset_strings(char *string1, char *string2, char *string3);//34

//Funzione che gestisce il ciclo di inserimento, ricezione, elaborazione ed invio delle stringhe, con controllo finale della stringa "quit", vuota, e chiusura connessione col Client.
int set_link_two_strings();//41

//Funzione che invia la stringa di benvenuto al Client, con le istruzioni per interagire col server.
// ERROR: Fare attenzione a non mettere un messaggio troppo grande che supera la BUFFER_SIZE
void send_welcome_message();//69

//Funzione che controlla se la stringa uno e due (dell'input) contengono "quit". I primi 4 caratteri vengono temporaneamente convertiti in minuscolo e la stringa viene comparata.
//Ritorna -1 se la stringa � uguale a "quit" (parole diverse come "quitabcd" non valgono).
//Ritorna -2 per stringe vuote. Nel caso il Client viene chiuso prima, la funzione avvisa la chiamante.
//Ritorna 0 se non ci sono problemi.
int string_control_quit(char *string1, char *string2);//74

