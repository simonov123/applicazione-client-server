#include "functions.h"


void run_server(){//funzione principale server
    build_socket();//socket di benvenuto
    set_socket_address();//configurazione oggetto sockaddr_in di benvenuto
    set_socket_listen();//server in ascolto
    puts("Execution finished.");//fine esecuzione
    block_screen();
}


void error_message(char *message){//error handler
    printf("%s", message);
    puts("");
    block_screen();
}



void block_screen(){//funzione blocco schermo con getch per Windows
    #if defined WIN32
        puts("Press a key to continue");
        getch();
    #endif // defined
}


void link_two_strings(char *string1, char *string2, char *return_string){//link delle due stringhe
    strcat(return_string, string1);
    strcat(return_string, string2);
    }

//le inizializza a vuote
void reset_strings(char *string1, char *string2, char *string3){//azzeramento dei buffer di invio e ricezione
    strcpy(string1, "");
    strcpy(string2, "");
    strcpy(string3, "");
}

//ERROR, QUANDO IL CLIENT VIENE CHIUSO PRIMA, CONTINUA AD ITERARE
int set_link_two_strings(){//funzione che gestisce il ciclo di inserimento e ricezione delle stringhe collegate
    char string_temp_1[BUFFER_SIZE];//buffer di ricezione
    char string_temp_2[BUFFER_SIZE];
    char string_temp_3[BUFFER_SIZE];//buffer di invio della stringa linkata
    reset_strings(string_temp_1, string_temp_2, string_temp_3);//reset
    receve_data(string_temp_1);//ricezione stringhe dal client nei buffer di ricezione
    printf("%s%s\n", "Client First Word is: ", string_temp_1);
    receve_data(string_temp_2);
    printf("%s%s\n", "Client Second Word is: ", string_temp_2);
    int control_quit = 0;
    control_quit = string_control_quit(string_temp_1, string_temp_2);//controllo eventuali stringhe di chiusura
    if(control_quit == -1){//caso -1:stringa di chiusura presente
        send_bye();//invio messaggio di chiusura
        return -1;
    }else{
        if(control_quit == -2){//caso -2:client chiuso prima della ricezione
            error_client_close_prematurely();//ErrorHandler
            return -1;
        }else{//caso 0 ricezione avvenuta con successo senza stringhe di chiusura
            link_two_strings(string_temp_1, string_temp_2, string_temp_3);//link delle stringhe
            send_data(string_temp_3);//invio della stringa linkata al client
            return 0;
            }
    }

}


void send_welcome_message(){//messaggio di benvenuto
    send_data("Connection with the server established.\nSend me two words that i link for you. Send me the word 'quit' to disconnect.");
}


int string_control_quit(char *string1, char *string2){//controllo stringhe di uscita
    char string_temp_1[BUFFER_SIZE] = "";//buffer temporanei per le stringhe ricevute
    char string_temp_2[BUFFER_SIZE] = "";
    strcpy(string_temp_1, string1);//copia nei buffer
    strcpy(string_temp_2, string2);
    for(int x = 0; x <4; x++){//caratteri settati a LOWER per attuare il confronto con quit(LOWER)
        string_temp_1[x]= tolower(string_temp_1[x]);
        string_temp_2[x]= tolower(string_temp_2[x]);
    }

    if((strcmp(string_temp_1, "quit") && strcmp(string_temp_2, "quit"))== 0) {//controllo
        return -1;
    }else{
        if((strcmp(string_temp_1, "") && strcmp(string_temp_2, ""))== 0){
            return -2;
        }else{
            return 0;
        }

    }

}



