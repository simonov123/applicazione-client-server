
#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <termios.h> //in prova
#endif // defined


#define CLIENT_PORT 4444
#define BUFFER_SIZE 200

//elimina l'oggetto WSA creato come descrittore socket per Windows
void clean_win_sock();//11

//crea la socket e controlla che venga creata. viene creata sia una socket unix sia un'oggetto WSA windows
void build_socket();//18

//valorizza l'oggetto sockaddr_in contenente l'indirizzo e il numero di porta della socket
void set_socket_server_address();//30

//inserisce la porta del server da contattare
int input_port();//40

//inserisce l'indirizzo IP da contattare
void input_address(char *address);//50

//connessione al server e controllo
int connect_server();//57

//prende in input nel buffer una stringa e la invia
void send_data(char *input_buffer);//67

//prende in input una stringa dal TCP e la passa all'applicazione
void receve_data(char *return_buffer);//73

//controlla che la connessione sia avvenuta con successo
int check_connect(int connection);//81

//controlla che la socket sia satata creata con successo
int check_socket(int my_socket);//89

//cancella le socket e pulisce lo schermo
int close_socket_and_clean(int descriptor);//99

//controlla che l'oggetto WSA sia stato creato con successo
void wsadata_check(int iresult);//104

//invoca la close socket
void close_client();//114

