#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#endif // defined


#define SERVER_PORT 12345//PORT

#define BUFFER_SIZE 200//DIMENSIONE BUFFER

//pulisce l'oggetto WSADATA
void clean_win_sock();//12

//crea un descrittore socket
void build_socket();//18

//avvalora l'oggetto sockaddrin per la socket del server e fa la bind
void set_socket_address();//24

//ottiene il nome di un client dal suo indirizzo IP inserito in una variabile globale
void get_client_name(char *return_client_name);//35

//routine del server. Dirige le azioni dal momento del pacchetto di benvenuto alla conversione delle vocali e il loro reinoltro
void server_routine(char *host_client_name);//42

//invia un carattere
void send_data(char *input_buffer);//76

//riceve un carattere
void receve_data(char *return_buffer);//83

//funzione di setup dell'ip del server tramite nome o come IP LOCALE 127.0.0.1 per permettere una connessione da client esterno all'ambito locale
void setup_ip();//94

//controlla che un simbolo sia un numero intero
void check_int(int numero);//146

//check successo creazione socket
int check_socket(int my_socket);//152

//check della bind
int check_bind(int check_x);//160

//controlla che il numero di porta inserito sia valido
int check_port(int argc, char *argv[]);//167

//verifica la corretta creaione dell'oggetto WSA
void wsadata_check(int iresult);//182

