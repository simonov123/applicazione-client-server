#include "server.h"
#define h_addr h_addr_list[0] /* for backward compatibility */

char IP_ADDRESS[16] = "";

int server_socket_descriptor;//socket di benvenuto e suo oggetto sockaddr_in
struct sockaddr_in server_addr;

struct sockaddr_in client_addr;
int client_socket_descriptor;
//int client_len;

void clean_win_sock() {//chiusura Winsock
#if defined WIN32
WSACleanup();
#endif // defined
}

void build_socket(){//creazione socket

    server_socket_descriptor = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
    check_socket(server_socket_descriptor);
}

void set_socket_address(){//configurazione socket di benvenuto
    memset(&server_addr,0,sizeof(server_addr));//azzeramento oggetto sockaddr_in
    server_addr.sin_family = AF_INET;//configurazione oggetto sockaddr_in
    server_addr.sin_addr.s_addr = inet_addr(IP_ADDRESS);
    server_addr.sin_port = htons(SERVER_PORT);

    //bind
    int bind_x = bind(server_socket_descriptor,(struct sockaddr*) &server_addr, sizeof(server_addr));
    check_bind(bind_x);//controllo bind
}

void get_client_name(char *return_client_name){
    struct hostent *host_client;
    host_client = gethostbyaddr( &client_addr.sin_addr, 4, AF_INET);
    strcpy(return_client_name, host_client->h_name);
}


void server_routine(char *host_client_name){

    int i = 0;
    char vowel_temp[2] = "";

    for(int i = 0;  i < BUFFER_SIZE; i++){
        receve_data(vowel_temp);

        if(vowel_temp[0] == '\0')
            break;

        printf("Host Name: %s", host_client_name);
        puts("");
        printf("Message received: %s", vowel_temp);
        puts("");
        puts("");

        vowel_temp[0] = toupper(vowel_temp[0]);
        send_data(vowel_temp);

    }

    send_data("The connection with the Server is closed.");

}







int input_buffer_len = 0;
//send e recieve data. con buffer passato per riferimento dai buffer per e stinghe
void send_data(char *input_buffer){
    input_buffer_len = strlen(input_buffer);

    sendto(server_socket_descriptor, input_buffer, input_buffer_len, 0, (struct sockaddr*)&client_addr, sizeof(client_addr));
}


void receve_data(char *return_buffer){
    char string[BUFFER_SIZE]= "";

    int client_addr_len  = sizeof(client_addr);

    recvfrom(server_socket_descriptor, string, sizeof(string),0, (struct sockaddr*)&client_addr, &client_addr_len);
    strcpy(return_buffer, string);

}


void setup_ip(){
    #if defined WIN32
	WSADATA WSAData;
	int iresult = WSAStartup(MAKEWORD(2,2), &WSAData);
	wsadata_check(iresult);
    #endif // defined

    char server_name[BUFFER_SIZE];
    char ip_address_temp[16];
    struct hostent *w;
    int menu_choise= 0;
    gethostname(server_name, BUFFER_SIZE);
    w = gethostbyname(server_name);
    strcpy(ip_address_temp,inet_ntoa(*(struct in_addr*)w->h_addr) );

    puts("Choose how to set your IP ADDRESS.");
    puts("Press 1 to set 'local' IP ADDRESS: '127.0.0.1'");

    printf("Press 2 to set your real IP ADDRESS: '%s'\n", ip_address_temp);

    while(menu_choise <= 0 || menu_choise >= 3){
        printf("Press your choise: ");
        menu_choise = input_int();
        puts("");

        switch(menu_choise){
            case 1:
                strcpy(IP_ADDRESS, "127.0.0.1");
                printf("SERVER NAME: %s\n", server_name);
                printf("IP SERVER: %s\n", IP_ADDRESS);
                puts("");
                break;

            case 2:
                strcpy(IP_ADDRESS, ip_address_temp);
                printf("SERVER NAME: %s\n", server_name);
                printf("IP SERVER: %s\n", IP_ADDRESS);
                puts("");
                break;

            default:
                puts("Wrong choise. Retry.");
            }
    }


}




//Sicurezza
void check_int(int numero){
    if(numero == 0){
        scanf("%*[^\n]");
    }
}

int check_socket(int my_socket){//check successo creazione socket
    if (my_socket < 0){
        error_message("Socket creation is failed.");
        return -1;
    }
}


int check_bind(int check_x){//check bind
    if(check_x < 0){
        error_message("Bind failed.");
        return -1;
    }
}

int check_port(int argc, char *argv[]){//check inserimento numero di porta valido

	int port;
	if (argc > 1){
		port = atoi(argv[1]);
	}
	else port = SERVER_PORT;	// Default
	if (port < 0){
		printf("Bad port number %s \n",argv[1]);
		return -1;
	}

}


void wsadata_check(int iresult){//check successo creazione oggetto WSADATA
    if (iresult!=0){
		error_message("Error at WSAStartup.");
        clean_win_sock();
		return -1;
	}
}


