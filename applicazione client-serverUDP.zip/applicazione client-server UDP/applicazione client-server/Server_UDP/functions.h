#include "server.h"

//ErrorHandler
void error_message(char *message);//3

//funzione blocco schermo con getch per Windows
void block_screen();//12

//routine del server. Configura l'IP e invoca le funzioni di configurazione del server
void run_server();//20

//accetta e gestisce una richiesta di connessione per poi avviare la routine di elaborazione delle stringhe
void waiting_connection();//31

//prende in input un'intero generico e lo controlla
int input_int();//61
