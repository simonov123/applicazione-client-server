#include "functions.h"


void error_message(char *message){//error handler
    printf("%s", message);
    puts("");
    block_screen();
}



void block_screen(){//funzione blocco schermo con getch per Windows
    #if defined WIN32
        puts("Press a key to continue");
        getch();
    #endif // defined
}


void run_server(){
    setup_ip();
    build_socket();//socket di benvenuto
    set_socket_address();//configurazione oggetto sockaddr_in di benvenuto

    waiting_connection();

    puts("Execution finished.");//fine esecuzione
    block_screen();
}

void waiting_connection(){
    puts("Waiting for a client to connect...");

    while(1){

        char receve_message[BUFFER_SIZE] = "";
        char send_message[BUFFER_SIZE] = "";

        receve_data(receve_message);

        char host_client_name[BUFFER_SIZE];

        get_client_name(host_client_name);


        printf("Host Name: %s", host_client_name);
        puts("");
        printf("Message received: %s", receve_message);
        puts("");
        puts("");

        send_data("OK");

        server_routine(host_client_name);

    }
}



int input_int(){//funzione di input di una stringa
    int number = 0;

    scanf("%d", &number);
    check_int(number);

    return number;
}

