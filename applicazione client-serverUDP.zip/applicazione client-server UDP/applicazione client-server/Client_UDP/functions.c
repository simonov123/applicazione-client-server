#include "functions.h"

void run_client(){ //funzione client principale
    build_socket();//crea socket client
    set_socket_server_address();//configura oggetto sockaddr_in

    int connection_check = welcome_echo();
    if(connection_check != -1){
        string_routine();
    }

    close_client();//uscita dal programma
    block_screen();
}

void error_message(char *message){//errorHandler
    printf("%s", message);
    puts("");
    block_screen();//blocco schermo
}



void block_screen(){//blocco schermo con getch
    #if defined WIN32
        puts("Press a key to continue");
        getch();
    #endif // defined
}



int welcome_echo(){
    char send_message[BUFFER_SIZE] = "";
    char receve_message[BUFFER_SIZE] = "";

    printf("%s", "Insert a welcome message: ");
    input_string(send_message);

    send_data(send_message);

    receve_data(receve_message);
    if (strcmp(receve_message, "OK") != 0){
        puts("Connection with server failed.");
        return -1;
    }
    printf("%s",receve_message);
    puts("");
}






//ROUTINE CLIENT STRINGHE DA AVVIARE ALLA RICEZIONE DI UN PACCHETTO DI BANVENUTO
//da mettere in iterazione nella funzione di connessione
int string_routine(){
    char string_temp[BUFFER_SIZE];
    printf("Insert a word: ");
    input_string(string_temp);
    puts("");
    vowel_routine(string_temp);
}

void vowel_routine(char *string_temp){

    int counter_vowel=0;

    for (unsigned int i=0; string_temp[i] != '\0' && i < BUFFER_SIZE ; i++)
    {
        if((check_vowel(string_temp[i]))==1){

            counter_vowel++;
            char character_temp[2];
            character_temp[0]=(string_temp[i]);
            character_temp[1]= '\0';

            send_data(character_temp);
            char returned_character[BUFFER_SIZE];
            receve_data(returned_character);
            printf("Server vowel %d: %s\n", counter_vowel, returned_character);
        }
    }
    char end_string[BUFFER_SIZE] = "\0";
    send_data(end_string);
    receve_data(end_string);
    printf("%s\n", end_string);

}

int check_vowel(char *c){
    char vowels[5] = { 'a', 'e', 'i', 'o', 'u' };

    for(unsigned int i=0; i<5; i++){
        if(c == vowels[i]){
            return 1;
        }
    }
    return 0;
}





//Aggiunta clean_buffer_input() per evitare problemi dove pi� parole immesse vengano salvate malamente

void input_string(char *string){//funzione di input di una stringa
    clean_buffer_input();
    scanf("%s",string);
    clean_buffer_input();
}
int input_port(){//input porta
    int port;
    printf("%s", "Insert a Port Number: ");
    clean_buffer_input();
    scanf("%d",&port);//input porta
    clean_buffer_input();
    return port;
}


void input_server_name(char *server_name){//input indirizzo IP
    printf("%s", "Insert 'localhost' to run in local host.\nInsert a valid server name or his IP: ");
    clean_buffer_input();  //pulizia input
    scanf("%s",server_name);
    clean_buffer_input();
}





void clean_buffer_input(){//pulizia buffer di input
    fflush(stdin);
}


