#include <string.h>

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#endif // defined


#define CLIENT_PORT 4444
#define BUFFER_SIZE 200

//elimina l'oggetto WSA creato per la socket Windows
void clean_win_sock();//13

//crea l'oggetto WSA e il descrittore della socket
void build_socket();//20

//serve ad avvalorare l'oggetto sockaddr_in destinato a contenere l'indirizzo del server con il quale si vuole comunicare. Invocherà una funzione di input del DNS del server,una gethost by name per ottenere l'IP,una funzione di input per inserire il numero di porta del server e il riempimento dell'oggetto sock_addrin destitnato al contatto con il server
void set_socket_server_address();//32

//invia un carattere al server
void send_data(char *input_buffer);//54

//riceve un carattere dal server
void receve_data(char *return_buffer);//61
