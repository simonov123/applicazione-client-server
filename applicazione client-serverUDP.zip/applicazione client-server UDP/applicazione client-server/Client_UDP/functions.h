#include <stdio.h>
#include "client.h"
 
 //funzione di start del client,nonchè prima funzione invocata. Invoca le funzioni di connessione e la funzione di routine del client.
 void run_client();//3
 
 //ErrorHandler
 void error_message(char *message);//16
 
 //blocco schermo con getch
 void block_screen();//24
 
 //funzione messaggio di benvenuto e conferma di connessione
 int welcome_echo();//33
 
 //funzione di start della routine,prende in input la stringa da processare e invoca la routine che seleziona le vocali
 int string_routine();//58
 
 //routine delle vocali,scorre i caratteri della stringa controllando che siano vocali. se è una vocale incrementa il contatore e la invia al server per poi riceverla in maiuscolo e stamparla a video; se è una consonante viene ignorata; se è il carattere di fine stringa /0 si esce dal ciclo FOR di routine.
 void vowel_routine(char *string_temp);//66
 
 //prende in input un carattere e stabilisce se è una vocale
 int check_vowel(char *c);//92
 
 //prende in input una stringa
 void input_string(char *string);//109
 
 //prende in input un numero di porta
 int input_port();//114 
 
 //prende in input il nome di un DNS
 void input_server_name(char *server_name);//124
 
 //pulisce il buffer input
 void input_server_name(char *server_name);//134
