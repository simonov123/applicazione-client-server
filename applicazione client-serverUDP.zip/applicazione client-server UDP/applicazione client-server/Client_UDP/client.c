#include "client.h"
#define h_addr h_addr_list[0] /* for backward compatibility */


int client_socket_descriptor;//client socket,variable globale

struct sockaddr_in from_addr;
struct sockaddr_in to_addr;

char ip_address[16];//indirizzo IP client
int client_port;//porta client

void clean_win_sock(){//funzione per distruggere la !insock
    #if defined WIN32
    WSACleanup();
    #endif // defined
}


void build_socket(){ //build oggetto WSA e socket
    #if defined WIN32
	WSADATA WSAData;//oggetto WSA+controllo Winsock
	int iresult = WSAStartup(MAKEWORD(2,2), &WSAData);
	wsadata_check(iresult);//controllo
    #endif // defined

    client_socket_descriptor = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);//creazione socket client
    check_socket(client_socket_descriptor);//controllo
}


void set_socket_server_address(){//indirizzamento oggetto sockaddr_in

    char server_name[BUFFER_SIZE];
    input_server_name(server_name);
    struct hostent *w;
    w = gethostbyname(server_name);

    strcpy(ip_address,inet_ntoa(*(struct in_addr*)w->h_addr) );

   // input_address(ip_address);   //input IP
    client_port=input_port();    //input porta
    memset(&to_addr,0,sizeof(to_addr));//azzeramento oggetto sockaddr_in
    to_addr.sin_family=AF_INET;            //configurazione oggetto sockaddr_in
    to_addr.sin_addr.s_addr=inet_addr(ip_address);       //inet_addr(ip_address);
    to_addr.sin_port=htons(client_port);
}




int input_buffer_len = 0;
//send e recieve data. con buffer passato per riferimento dai buffer per e stinghe
void send_data(char *input_buffer){
    input_buffer_len = strlen(input_buffer);
    int to_addr_len  = sizeof(to_addr);
    sendto(client_socket_descriptor, input_buffer, input_buffer_len, 0, (struct sockaddr*)&to_addr, &to_addr_len);
}


void receve_data(char *return_buffer){

    char string[BUFFER_SIZE]= "";
    int x  = sizeof(to_addr);
    recvfrom(client_socket_descriptor, string, BUFFER_SIZE-1,0, (struct sockaddr*)&from_addr, &x);

    strcpy(return_buffer, string);
}






//sicurezza

int check_socket(int my_socket){//controllo creazione socket
     if (my_socket < 0){
        error_message("Socket creation is failed.");
        close_socket_and_clean(client_socket_descriptor);
        return -1;
    }
}



int close_socket_and_clean(int descriptor){//funzione di chiusura socket e Winsock
    closesocket(descriptor);
    clean_win_sock;
}


void wsadata_check(int iresult){ //check oggetto WSA
    if (iresult!=0){
		error_message("Error at WSAStartup.");
        clean_win_sock();
		return -1;
	}
}



void close_client(){//invocazione astratta chiusura
    close_socket_and_clean(client_socket_descriptor);
    printf("%s", "The application is closing.");
}
